-- OPTIONAL, additive RLS policies for restaurant owners to read/write
-- their own data directly from the client (defense-in-depth alongside
-- the backend API, NOT a replacement for it).
--
-- IMPORTANT CONTEXT: earlier in this project, RLS was deliberately locked
-- down to zero policies for anon/authenticated, specifically so that only
-- the Express backend's service-role key could touch these tables. That
-- was an explicit, confirmed decision: "the backend is the only trusted
-- layer... block direct client access." This migration reopens a narrow
-- slice of that for restaurant owners only, scoped strictly to their own
-- restaurant's data.
--
-- Running this migration means: an owner's browser can now read/write
-- their own restaurant's rows directly via the Supabase client, in
-- addition to the dashboard now also using the real backend API (which
-- is what actually got fixed in this pass). If you don't have a specific
-- reason to want direct-client access as a fallback, you can skip this
-- file entirely and the dashboard will work correctly through the API
-- alone - review before running.

-- Helper: resolve the internal users.id for the currently authenticated
-- Supabase user, since restaurants.owner_id references users.id, not
-- auth.uid() directly.
CREATE OR REPLACE FUNCTION public.current_app_user_id()
RETURNS uuid
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT id FROM public.users WHERE supabase_uid = auth.uid();
$$;

REVOKE EXECUTE ON FUNCTION public.current_app_user_id() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.current_app_user_id() TO authenticated;

-- restaurants: owner can read/update their own restaurant only
CREATE POLICY owner_select_own_restaurant ON public.restaurants
  FOR SELECT TO authenticated
  USING (owner_id = public.current_app_user_id());

CREATE POLICY owner_update_own_restaurant ON public.restaurants
  FOR UPDATE TO authenticated
  USING (owner_id = public.current_app_user_id())
  WITH CHECK (owner_id = public.current_app_user_id());

-- restaurant_tables: owner can manage tables for their own restaurant only
CREATE POLICY owner_manage_own_tables ON public.restaurant_tables
  FOR ALL TO authenticated
  USING (restaurant_id IN (SELECT id FROM public.restaurants WHERE owner_id = public.current_app_user_id()))
  WITH CHECK (restaurant_id IN (SELECT id FROM public.restaurants WHERE owner_id = public.current_app_user_id()));

-- bookings: owner can read (not write) bookings for their own restaurant
CREATE POLICY owner_select_own_bookings ON public.bookings
  FOR SELECT TO authenticated
  USING (restaurant_id IN (SELECT id FROM public.restaurants WHERE owner_id = public.current_app_user_id()));

-- notifications: owner can read/update (mark read) their own restaurant's notifications
CREATE POLICY owner_select_own_notifications ON public.notifications
  FOR SELECT TO authenticated
  USING (restaurant_id IN (SELECT id FROM public.restaurants WHERE owner_id = public.current_app_user_id()));

CREATE POLICY owner_update_own_notifications ON public.notifications
  FOR UPDATE TO authenticated
  USING (restaurant_id IN (SELECT id FROM public.restaurants WHERE owner_id = public.current_app_user_id()))
  WITH CHECK (restaurant_id IN (SELECT id FROM public.restaurants WHERE owner_id = public.current_app_user_id()));

-- Deliberately NOT included: INSERT/DELETE on restaurants, payments
-- (any status/amount access), and anything cross-restaurant. Those stay
-- backend-only regardless of this migration.
