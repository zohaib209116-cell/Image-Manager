import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { getRestaurant, updateRestaurant } from "@/lib/api";
import { sanitizeStr, safeErrorMessage } from "@/lib/security";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { ImageUpload } from "@/components/ImageUpload";
import { uploadRestaurantImage } from "@/lib/imageUpload";
import { Loader2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";

// Structured per-day hours, stored as JSON text inside restaurants.hours
// (a plain text column on the backend - not a separate structured table).
type DayHours = { open: string; close: string; closed: boolean };
type WeekHours = Record<string, DayHours>;

const DEFAULT_HOURS: WeekHours = {
  monday: { open: "11:00", close: "23:00", closed: false },
  tuesday: { open: "11:00", close: "23:00", closed: false },
  wednesday: { open: "11:00", close: "23:00", closed: false },
  thursday: { open: "11:00", close: "23:00", closed: false },
  friday: { open: "11:00", close: "00:00", closed: false },
  saturday: { open: "11:00", close: "00:00", closed: false },
  sunday: { open: "11:00", close: "23:00", closed: false },
};

function parseHours(raw?: string): WeekHours {
  if (!raw) return DEFAULT_HOURS;
  try {
    const parsed = JSON.parse(raw);
    return { ...DEFAULT_HOURS, ...parsed };
  } catch {
    return DEFAULT_HOURS;
  }
}

export default function Profile() {
  const { restaurantId } = useAuth();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  const [formData, setFormData] = useState({
    name: "",
    city: "",
    area: "",
    cuisine: "",
    description: "",
    phone: "",
    image_url: "",
  });

  const [hours, setHours] = useState<WeekHours>(DEFAULT_HOURS);

  useEffect(() => {
    const fetchProfile = async () => {
      if (!restaurantId) return;
      try {
        const data = await getRestaurant(restaurantId);
        setFormData({
          name: data.name || "",
          city: data.city || "",
          area: data.area || "",
          cuisine: data.cuisine || "",
          description: data.description || "",
          phone: data.phone || "",
          image_url: data.image_url || "",
        });
        setHours(parseHours(data.hours));
      } catch (error: any) {
        toast({ title: "Couldn't load profile", description: safeErrorMessage(error), variant: "destructive" });
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, [restaurantId, toast]);

  const handleSave = async () => {
    if (!restaurantId || saving) return;

    const cleanName = sanitizeStr(formData.name, 120);
    if (!cleanName) {
      toast({ title: "Validation Error", description: "Restaurant name is required.", variant: "destructive" });
      return;
    }

    setSaving(true);
    try {
      await updateRestaurant(restaurantId, {
        name: cleanName,
        city: sanitizeStr(formData.city, 100),
        area: sanitizeStr(formData.area, 100),
        cuisine: sanitizeStr(formData.cuisine, 80),
        description: sanitizeStr(formData.description, 1000),
        phone: sanitizeStr(formData.phone, 20),
        image_url: sanitizeStr(formData.image_url, 2000),
        // hours is a text column on the backend - store the structured
        // per-day schedule as a JSON string rather than needing a schema
        // change right now.
        hours: JSON.stringify(hours),
      });
      toast({ title: "Profile Updated", description: "Your restaurant profile has been saved." });
    } catch (error: any) {
      toast({ title: "Error", description: safeErrorMessage(error), variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const handleHoursChange = (day: string, field: string, value: string | boolean) => {
    setHours((prev) => ({ ...prev, [day]: { ...prev[day], [field]: value } }));
  };

  if (loading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-96 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const days = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"];

  return (
    <div className="space-y-8 max-w-4xl mx-auto">
      <div>
        <h2 className="text-3xl font-serif tracking-tight text-gradient-gold">Restaurant Profile</h2>
        <p className="text-muted-foreground mt-1">Manage how your restaurant appears to customers.</p>
      </div>

      <div className="flex justify-end">
        <Button onClick={handleSave} disabled={saving} className="bg-gradient-gold text-primary-foreground shadow-gold hover-lift">
          {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
          Save Changes
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="font-serif">Basic Information</CardTitle>
          <CardDescription>Essential details about your restaurant.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label>Cover Image</Label>
            <ImageUpload
              onUpload={(url) => setFormData((prev) => ({ ...prev, image_url: url }))}
              uploadFn={uploadRestaurantImage}
              currentImageUrl={formData.image_url}
            />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="name">Restaurant Name</Label>
              <Input id="name" value={formData.name} maxLength={120} onChange={(e) => setFormData((prev) => ({ ...prev, name: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input id="phone" value={formData.phone} maxLength={20} onChange={(e) => setFormData((prev) => ({ ...prev, phone: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="city">City</Label>
              <Input id="city" value={formData.city} maxLength={100} onChange={(e) => setFormData((prev) => ({ ...prev, city: e.target.value }))} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="area">Area / Neighborhood</Label>
              <Input id="area" value={formData.area} maxLength={100} onChange={(e) => setFormData((prev) => ({ ...prev, area: e.target.value }))} />
            </div>
            <div className="space-y-2 md:col-span-2">
              <Label htmlFor="cuisine">Cuisine Type</Label>
              <Input id="cuisine" placeholder="e.g. Desi, Chinese, Continental" value={formData.cuisine} maxLength={80} onChange={(e) => setFormData((prev) => ({ ...prev, cuisine: e.target.value }))} />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              rows={4}
              placeholder="Tell customers about your restaurant's vibe and specialties..."
              value={formData.description}
              maxLength={1000}
              onChange={(e) => setFormData((prev) => ({ ...prev, description: e.target.value }))}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="font-serif">Operating Hours</CardTitle>
          <CardDescription>Set your regular opening and closing times.</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {days.map((day) => {
              const dayData = hours[day];
              return (
                <div key={day} className="flex items-center justify-between gap-4 p-3 border rounded-lg bg-card/50">
                  <div className="w-24 font-medium capitalize">{day}</div>
                  <div className="flex items-center gap-4 flex-1">
                    {!dayData.closed ? (
                      <>
                        <Input type="time" value={dayData.open} onChange={(e) => handleHoursChange(day, "open", e.target.value)} className="w-32" />
                        <span>to</span>
                        <Input type="time" value={dayData.close} onChange={(e) => handleHoursChange(day, "close", e.target.value)} className="w-32" />
                      </>
                    ) : (
                      <span className="text-muted-foreground italic px-4">Closed all day</span>
                    )}
                  </div>
                  <Button variant={dayData.closed ? "default" : "outline"} size="sm" onClick={() => handleHoursChange(day, "closed", !dayData.closed)}>
                    {dayData.closed ? "Open" : "Mark Closed"}
                  </Button>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
