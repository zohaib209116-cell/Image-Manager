import { useState, useEffect } from "react";
import { useAuth } from "@/hooks/useAuth";
import { getDashboardStats, getRestaurantReservations, type Booking } from "@/lib/api";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ResponsiveContainer, LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from "recharts";
import { Skeleton } from "@/components/ui/skeleton";
import { formatPKR } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";

export default function Analytics() {
  const { restaurantId } = useAuth();
  const { toast } = useToast();
  const [loading, setLoading] = useState(true);
  const [metrics, setMetrics] = useState({ totalBookings: 0, completionRate: 0, cancellationRate: 0, totalRevenue: 0 });
  const [bookingsByDay, setBookingsByDay] = useState<any[]>([]);
  const [partySizeData, setPartySizeData] = useState<any[]>([]);
  const [timeSlotData, setTimeSlotData] = useState<any[]>([]);

  const COLORS = ["#c4a15a", "#e5c88a", "#8a6d3b", "#f0dfae", "#5a4526"];

  useEffect(() => {
    const fetchAnalytics = async () => {
      if (!restaurantId) return;
      try {
        const [stats, bookings]: [any, Booking[]] = await Promise.all([
          getDashboardStats(restaurantId),
          getRestaurantReservations(restaurantId),
        ]);

        const total = bookings.length;
        const completed = bookings.filter((b) => b.status === "completed").length;
        const cancelled = bookings.filter((b) => b.status === "cancelled" || b.status === "rejected").length;

        setMetrics({
          totalBookings: stats.bookings?.total_bookings ?? total,
          completionRate: total ? Math.round((completed / total) * 100) : 0,
          cancellationRate: total ? Math.round((cancelled / total) * 100) : 0,
          totalRevenue: Number(stats.revenue?.total_revenue ?? 0),
        });

        const last7Days = Array.from({ length: 7 }, (_, i) => {
          const d = new Date();
          d.setDate(d.getDate() - i);
          return d.toISOString().split("T")[0];
        }).reverse();

        const byDay = last7Days.map((dateStr) => {
          const count = bookings.filter((b) => b.booking_date === dateStr).length;
          return { date: new Date(dateStr).toLocaleDateString("en-US", { weekday: "short" }), count };
        });
        setBookingsByDay(byDay);

        const sizes = { "2": 0, "4": 0, "6": 0, "8+": 0 };
        bookings.forEach((b) => {
          const s = b.guests;
          if (s <= 2) sizes["2"]++;
          else if (s <= 4) sizes["4"]++;
          else if (s <= 6) sizes["6"]++;
          else sizes["8+"]++;
        });
        setPartySizeData(
          [
            { name: "1-2 People", value: sizes["2"] },
            { name: "3-4 People", value: sizes["4"] },
            { name: "5-6 People", value: sizes["6"] },
            { name: "7+ People", value: sizes["8+"] },
          ].filter((d) => d.value > 0)
        );

        const slots: Record<string, number> = {};
        bookings.forEach((b) => {
          slots[b.booking_time] = (slots[b.booking_time] || 0) + 1;
        });
        setTimeSlotData(
          Object.entries(slots)
            .map(([time, count]) => ({ time, count }))
            .sort((a, b) => b.count - a.count)
            .slice(0, 5)
        );

        setLoading(false);
      } catch (error: any) {
        console.error(error);
        toast({ title: "Couldn't load analytics", description: error.message, variant: "destructive" });
        setLoading(false);
      }
    };
    fetchAnalytics();
  }, [restaurantId, toast]);

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-serif tracking-tight text-gradient-gold">Analytics</h2>
        <p className="text-muted-foreground mt-1">Insights and performance metrics for your restaurant.</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">Total Bookings</CardTitle></CardHeader>
          <CardContent><div className="text-3xl font-bold text-foreground">{metrics.totalBookings}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">Total Revenue</CardTitle></CardHeader>
          <CardContent><div className="text-3xl font-bold text-primary">{formatPKR(metrics.totalRevenue)}</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">Completion Rate</CardTitle></CardHeader>
          <CardContent><div className="text-3xl font-bold text-green-500">{metrics.completionRate}%</div></CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2"><CardTitle className="text-sm font-medium text-muted-foreground">Cancellation Rate</CardTitle></CardHeader>
          <CardContent><div className="text-3xl font-bold text-destructive">{metrics.cancellationRate}%</div></CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="col-span-2 md:col-span-1">
          <CardHeader><CardTitle>Bookings Last 7 Days</CardTitle></CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={bookingsByDay} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="date" stroke="#888" />
                <YAxis stroke="#888" allowDecimals={false} />
                <Tooltip contentStyle={{ backgroundColor: "hsl(0 0% 8%)", borderColor: "hsl(40 15% 18%)" }} />
                <Line type="monotone" dataKey="count" stroke="#c4a15a" strokeWidth={3} dot={{ r: 4 }} activeDot={{ r: 8 }} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="col-span-2 md:col-span-1">
          <CardHeader><CardTitle>Popular Time Slots</CardTitle></CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={timeSlotData} margin={{ top: 5, right: 20, bottom: 5, left: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#333" />
                <XAxis dataKey="time" stroke="#888" />
                <YAxis stroke="#888" allowDecimals={false} />
                <Tooltip contentStyle={{ backgroundColor: "hsl(0 0% 8%)", borderColor: "hsl(40 15% 18%)" }} cursor={{ fill: "hsl(0 0% 14%)" }} />
                <Bar dataKey="count" fill="#e5c88a" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="col-span-2 md:col-span-1">
          <CardHeader><CardTitle>Party Size Distribution</CardTitle></CardHeader>
          <CardContent className="h-[300px]">
            {partySizeData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={partySizeData} cx="50%" cy="50%" innerRadius={60} outerRadius={100} paddingAngle={5} dataKey="value">
                    {partySizeData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: "hsl(0 0% 8%)", borderColor: "hsl(40 15% 18%)" }} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-full text-muted-foreground">Not enough data</div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
