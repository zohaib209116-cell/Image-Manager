import { useState, useEffect, useCallback } from "react";
import { useAuth } from "@/hooks/useAuth";
import { getRestaurantTables, createTable, updateTable, deleteTable, type RestaurantTable } from "@/lib/api";
import { sanitizeStr, sanitizeNum, safeErrorMessage } from "@/lib/security";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Plus, Users, Edit, RefreshCw } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

// The backend's restaurant_tables.status column only allows these three
// values (a CHECK constraint) - "occupied" and "maintenance" from the old
// version of this page aren't valid and would be rejected by the database.
const VALID_STATUSES = ["available", "reserved", "unavailable"] as const;
const VALID_LOCATIONS = ["indoor", "outdoor", "rooftop", "patio"] as const;

export default function Tables() {
  const { restaurantId, loading: authLoading } = useAuth();
  const [tables, setTables] = useState<RestaurantTable[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTable, setEditingTable] = useState<RestaurantTable | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [isDeleting, setIsDeleting] = useState<string | null>(null);

  const [tableNumber, setTableNumber] = useState("");
  const [capacity, setCapacity] = useState("");
  const [location, setLocation] = useState<string>("indoor");
  const [status, setStatus] = useState<string>("available");

  const { toast } = useToast();

  const fetchTables = useCallback(async () => {
    if (!restaurantId) return;
    try {
      const data = await getRestaurantTables(restaurantId);
      setTables([...data].sort((a, b) => a.table_number.localeCompare(b.table_number, undefined, { numeric: true })));
    } catch (error: any) {
      toast({ title: "Couldn't load tables", description: safeErrorMessage(error), variant: "destructive" });
    } finally {
      setLoading(false);
    }
  }, [restaurantId, toast]);

  useEffect(() => {
    if (authLoading) return;
    if (!restaurantId) {
      setLoading(false);
      return;
    }
    setLoading(true);
    fetchTables();
    // Note: this used to be a live Supabase realtime subscription. That
    // requires direct client access to the database, which was deliberately
    // shut off in favor of the backend being the only trusted layer - so
    // table status now updates on refresh/action rather than live-pushing.
  }, [restaurantId, authLoading, fetchTables]);

  const resetForm = () => {
    setTableNumber("");
    setCapacity("");
    setLocation("indoor");
    setStatus("available");
    setEditingTable(null);
  };

  const handleOpenModal = (table: RestaurantTable | null = null) => {
    if (table) {
      setEditingTable(table);
      setTableNumber(table.table_number);
      setCapacity(table.capacity.toString());
      setLocation(table.location || "indoor");
      setStatus(table.status || "available");
    } else {
      resetForm();
    }
    setIsModalOpen(true);
  };

  const handleSave = async () => {
    if (isSaving || !restaurantId) return;

    const cleanTableNum = sanitizeStr(tableNumber, 20);
    const cleanCapacity = sanitizeNum(capacity, 1, 100);
    const cleanLocation = VALID_LOCATIONS.includes(location as any) ? location : null;
    const cleanStatus = VALID_STATUSES.includes(status as any) ? status : null;

    if (!cleanTableNum) { toast({ title: "Validation Error", description: "Table number/name is required.", variant: "destructive" }); return; }
    if (cleanCapacity === null) { toast({ title: "Validation Error", description: "Capacity must be between 1 and 100.", variant: "destructive" }); return; }
    if (!cleanLocation) { toast({ title: "Validation Error", description: "Invalid location selected.", variant: "destructive" }); return; }
    if (!cleanStatus) { toast({ title: "Validation Error", description: "Invalid status selected.", variant: "destructive" }); return; }

    setIsSaving(true);
    try {
      if (editingTable) {
        await updateTable(editingTable.id, { table_number: cleanTableNum, capacity: cleanCapacity, location: cleanLocation, status: cleanStatus });
        toast({ title: "Table Updated", description: "Table has been updated successfully." });
      } else {
        await createTable({ restaurant_id: restaurantId, table_number: cleanTableNum, capacity: cleanCapacity, location: cleanLocation });
        toast({ title: "Table Added", description: "Table has been added successfully." });
      }
      setIsModalOpen(false);
      resetForm();
      fetchTables();
    } catch (error: any) {
      toast({ title: "Error", description: safeErrorMessage(error), variant: "destructive" });
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (isDeleting) return;
    setIsDeleting(id);
    try {
      await deleteTable(id);
      toast({ title: "Table Removed", description: "Table has been removed." });
      fetchTables();
    } catch (error: any) {
      toast({ title: "Error", description: safeErrorMessage(error), variant: "destructive" });
    } finally {
      setIsDeleting(null);
    }
  };

  const handleStatusChange = async (id: string, newStatus: string) => {
    if (!VALID_STATUSES.includes(newStatus as any)) return;
    try {
      await updateTable(id, { status: newStatus });
      toast({ title: "Status Updated", description: `Table status changed to ${newStatus}.` });
      fetchTables();
    } catch (error: any) {
      toast({ title: "Error", description: safeErrorMessage(error), variant: "destructive" });
    }
  };

  const getStatusColor = (s: string) => {
    switch (s) {
      case "available": return "bg-green-500/10 border-green-500 text-green-500";
      case "reserved": return "bg-yellow-500/10 border-yellow-500 text-yellow-500";
      case "unavailable": return "bg-gray-500/10 border-gray-500 text-gray-400";
      default: return "bg-card border-border";
    }
  };

  if (loading) {
    return <div className="grid gap-4 md:grid-cols-4 lg:grid-cols-6">{[1, 2, 3, 4, 5, 6, 7, 8].map((i) => <Skeleton key={i} className="h-32 w-full" />)}</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-serif tracking-tight text-gradient-gold">Table Management</h2>
          <div className="flex gap-4 mt-2 text-sm">
            <span className="flex items-center"><span className="w-3 h-3 rounded-full bg-green-500 mr-2"></span>Available</span>
            <span className="flex items-center"><span className="w-3 h-3 rounded-full bg-yellow-500 mr-2"></span>Reserved</span>
            <span className="flex items-center"><span className="w-3 h-3 rounded-full bg-gray-500 mr-2"></span>Unavailable</span>
          </div>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="icon" onClick={fetchTables} title="Refresh"><RefreshCw className="h-4 w-4" /></Button>
          <Dialog open={isModalOpen} onOpenChange={(open) => { setIsModalOpen(open); if (!open) resetForm(); }}>
            <DialogTrigger asChild>
              <Button onClick={() => handleOpenModal()} className="gap-2 bg-gradient-gold text-primary-foreground shadow-gold hover-lift"><Plus className="h-4 w-4" /> Add Table</Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[425px]">
              <DialogHeader>
                <DialogTitle className="font-serif">{editingTable ? "Edit Table" : "Add Table"}</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="tableNumber">Table Number/Name</Label>
                    <Input id="tableNumber" placeholder="e.g. T1, Balcony-1" value={tableNumber} onChange={(e) => setTableNumber(e.target.value)} maxLength={20} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="capacity">Capacity (Seats)</Label>
                    <Input id="capacity" type="number" min="1" max="100" value={capacity} onChange={(e) => setCapacity(e.target.value)} />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label>Location</Label>
                  <Select value={location} onValueChange={setLocation}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="indoor">Indoor</SelectItem>
                      <SelectItem value="outdoor">Outdoor</SelectItem>
                      <SelectItem value="rooftop">Rooftop</SelectItem>
                      <SelectItem value="patio">Patio</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Current Status</Label>
                  <Select value={status} onValueChange={setStatus}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="available">Available</SelectItem>
                      <SelectItem value="reserved">Reserved</SelectItem>
                      <SelectItem value="unavailable">Unavailable</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="flex justify-between items-center">
                {editingTable ? (
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" size="sm" disabled={isDeleting === editingTable?.id}>Remove Table</Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>Remove Table</AlertDialogTitle>
                        <AlertDialogDescription>Are you sure? This permanently deletes the table.</AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>Cancel</AlertDialogCancel>
                        <AlertDialogAction onClick={() => { handleDelete(editingTable.id); setIsModalOpen(false); }}>Remove</AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                ) : <div />}
                <div className="flex gap-2">
                  <Button variant="outline" onClick={() => setIsModalOpen(false)}>Cancel</Button>
                  <Button onClick={handleSave} disabled={isSaving} className="bg-gradient-gold text-primary-foreground">{isSaving ? "Saving..." : "Save"}</Button>
                </div>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid gap-4 grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
        {tables.length === 0 ? (
          <div className="col-span-full py-12 text-center text-muted-foreground border-2 border-dashed border-border rounded-lg">No tables configured yet.</div>
        ) : (
          tables.map((table) => (
            <Card key={table.id} className={cn("relative overflow-hidden cursor-pointer border-2 transition-all hover:-translate-y-1", getStatusColor(table.status))}>
              <div
                className="absolute inset-0"
                onClick={() => {
                  const nextStatus = table.status === "available" ? "reserved" : table.status === "reserved" ? "unavailable" : "available";
                  handleStatusChange(table.id, nextStatus);
                }}
              />
              <CardContent className="p-4 flex flex-col items-center justify-center text-center h-32 relative z-10 pointer-events-none">
                <span className="text-2xl font-serif font-bold mb-1">{table.table_number}</span>
                <div className="flex items-center text-sm font-medium opacity-80">
                  <Users className="h-4 w-4 mr-1" /> {table.capacity}
                </div>
                <span className="text-xs mt-2 uppercase tracking-wider opacity-60 font-semibold">{table.location}</span>
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute top-1 right-1 h-6 w-6 pointer-events-auto bg-background/50 hover:bg-background"
                  onClick={(e) => { e.stopPropagation(); handleOpenModal(table); }}
                >
                  <Edit className="h-3 w-3" />
                </Button>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  );
}
