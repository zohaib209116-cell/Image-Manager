import { Card, CardContent } from "@/components/ui/card";
import { Users } from "lucide-react";

// The previous version of this page queried a "staff" table directly via
// the Supabase client. That table does not exist anywhere in the real
// database - it was never created, and no backend routes for staff
// management exist either. Rather than ship a page that silently fails
// every request, this is a clear "not available yet" state until a real
// decision is made on the staff feature: a new `staff` table, ownership
// rules, and /api/staff routes on the backend, matching the pattern the
// rest of this dashboard now follows.
export default function Staff() {
  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-serif tracking-tight text-gradient-gold">Staff Management</h2>
        <p className="text-muted-foreground mt-1">Manage your restaurant's team.</p>
      </div>

      <Card className="border-dashed">
        <CardContent className="py-16 flex flex-col items-center text-center gap-3">
          <div className="p-3 rounded-full bg-muted text-muted-foreground">
            <Users className="h-6 w-6" />
          </div>
          <p className="font-serif text-lg text-foreground">Staff management isn't available yet</p>
          <p className="text-muted-foreground max-w-md text-sm">
            This feature needs a staff table and API routes added to the backend first -
            it isn't a UI gap, there's simply nowhere for this data to live yet.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
