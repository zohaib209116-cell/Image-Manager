// src/lib/api.ts
//
// Single entry point for every call to the Dastarkhuwa backend (Express
// on Railway). This dashboard previously queried Supabase directly from
// the browser via supabase.from(...) - that access pattern was deliberately
// shut off when RLS was locked down to "service-role backend only." Every
// data operation in this dashboard must now go through here instead.
//
// Set VITE_API_BASE_URL in this project's environment variables to your
// Railway backend URL, e.g. https://backend-production-xxxx.up.railway.app

import { supabase } from "@/lib/supabase";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL as string | undefined;

if (!API_BASE_URL) {
  // eslint-disable-next-line no-console
  console.error(
    "VITE_API_BASE_URL is not set. Set it in this project's environment " +
    "variables to your Railway backend URL."
  );
}

export class ApiError extends Error {
  status: number;
  errorCode?: string;
  errors?: Record<string, string>;

  constructor(status: number, message: string, errorCode?: string, errors?: Record<string, string>) {
    super(message);
    this.status = status;
    this.errorCode = errorCode;
    this.errors = errors;
  }
}

async function getAuthHeader(): Promise<Record<string, string>> {
  const { data } = await supabase.auth.getSession();
  const token = data.session?.access_token;
  return token ? { Authorization: `Bearer ${token}` } : {};
}

async function request<T>(
  path: string,
  options: { method?: string; body?: unknown; auth?: boolean } = {}
): Promise<T> {
  const { method = "GET", body, auth = true } = options;

  const headers: Record<string, string> = { "Content-Type": "application/json" };
  if (auth) Object.assign(headers, await getAuthHeader());

  const response = await fetch(`${API_BASE_URL}${path}`, {
    method,
    headers,
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  let payload: any = null;
  try {
    payload = await response.json();
  } catch {
    // non-JSON response
  }

  if (!response.ok) {
    const message = payload?.message || `Request failed with status ${response.status}`;
    throw new ApiError(response.status, message, payload?.error_code, payload?.errors);
  }

  // Backend wraps successful responses as { success: true, data }
  return (payload?.data ?? payload) as T;
}

// ---- Types matching what the backend actually returns ----

export interface Restaurant {
  id: string;
  owner_id: string;
  name: string;
  city: string;
  area?: string;
  cuisine?: string;
  description?: string;
  phone?: string;
  image_url?: string;
  is_active: boolean;
  avg_bill?: number;
  rating?: number;
  review_count?: number;
  hours?: string;
  created_at: string;
}

export interface RestaurantTable {
  id: string;
  restaurant_id: string;
  table_number: string;
  capacity: number;
  location?: string;
  status: "available" | "reserved" | "unavailable";
}

export interface Booking {
  id: string;
  user_id: string;
  restaurant_id: string;
  table_id: string;
  customer_name?: string;
  phone?: string;
  booking_date: string;
  booking_time: string;
  guests: number;
  occasion_type: string;
  status: string;
  bill_amount: number;
  service_fee: number;
  advance_amount: number;
  commission_amount: number;
  special_requests?: string | null;
  created_at: string;
}

export interface DashboardStats {
  [key: string]: any;
}

export interface Notification {
  id: string;
  user_id?: string;
  restaurant_id?: string;
  title: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

// ---- Restaurants ----

export const getMyRestaurants = () => request<Restaurant[]>("/api/restaurants/mine");

export const getRestaurant = (id: string) => request<Restaurant>(`/api/restaurants/${id}`, { auth: false });

export interface UpdateRestaurantInput {
  name: string;
  city: string;
  area?: string;
  cuisine?: string;
  description?: string;
  phone?: string;
  image_url?: string;
  hours?: string;
}

export const updateRestaurant = (id: string, input: UpdateRestaurantInput) =>
  request<Restaurant>(`/api/restaurants/${id}`, { method: "PUT", body: input });

// ---- Tables ----

export const getRestaurantTables = (restaurantId: string) =>
  request<RestaurantTable[]>(`/api/tables/${restaurantId}`);

export interface CreateTableInput {
  restaurant_id: string;
  table_number: string;
  capacity: number;
  location?: string;
}

export const createTable = (input: CreateTableInput) =>
  request<RestaurantTable>("/api/tables", { method: "POST", body: input });

export const updateTable = (id: string, input: Partial<CreateTableInput> & { status?: string }) =>
  request<RestaurantTable>(`/api/tables/${id}`, { method: "PUT", body: input });

export const deleteTable = (id: string) =>
  request<{ message: string }>(`/api/tables/${id}`, { method: "DELETE" });

// ---- Reservations / analytics ----

export const getRestaurantReservations = (restaurantId: string) =>
  request<Booking[]>(`/api/reservations/${restaurantId}`);

export const getDashboardStats = (restaurantId: string) =>
  request<DashboardStats>(`/api/dashboard/stats/${restaurantId}`);

export const updateReservationStatus = (id: string, status: string) =>
  request<Booking>(`/api/reservations/${id}/status`, { method: "PUT", body: { status } });

// ---- Notifications ----

export const getRestaurantNotifications = (restaurantId: string) =>
  request<Notification[]>(`/api/notifications/restaurant/${restaurantId}`);

export const markNotificationRead = (id: string) =>
  request<Notification>(`/api/notifications/${id}/read`, { method: "PUT" });
