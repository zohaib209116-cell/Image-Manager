import { useEffect, useState, useCallback, ReactNode } from "react";
import type { User } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabase";
import { secureLogout } from "@/lib/auth";
import { getMyRestaurants } from "@/lib/api";
import { useToast } from "@/hooks/use-toast";
import { AuthContext, type RestaurantData, type RestaurantDoc } from "@/contexts/authContextDef";

const SINGLE_KEY = "dastarkhuwa_restaurant";
const MULTI_KEY = "dastarkhuwa_session_restaurant";

// Previously this queried `supabase.from("restaurants").eq("owner_id", userId)`
// directly from the browser, using the Supabase Auth user id. Two real bugs:
// 1. Direct client access is blocked - RLS was locked down to service-role
//    only, so this always returned an empty array and force-logged out
//    every real owner.
// 2. `owner_id` on restaurants references public.users.id, NOT the Supabase
//    Auth uid - even with RLS reopened, that comparison would never match.
// Going through /api/restaurants/mine fixes both: the backend's auth
// middleware already resolves the Supabase uid to the correct internal
// user id before checking ownership.
async function loadOwnerRestaurants(): Promise<RestaurantDoc[]> {
  try {
    const rows = await getMyRestaurants();
    return rows.map((row) => ({
      id: row.id,
      queryId: row.id,
      data: row as unknown as RestaurantData,
    }));
  } catch (e) {
    console.warn("[Auth] Failed to load restaurants:", e);
    return [];
  }
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [restaurants, setRestaurants] = useState<RestaurantDoc[]>([]);
  const [activeQueryId, setActiveQueryId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  const handleUserSession = useCallback(async (currentUser: User) => {
    setLoading(true);
    const found = await loadOwnerRestaurants();
    console.log("[Auth] UID:", currentUser.id, "→ restaurants:", found.map((r) => r.id).join(", ") || "none");

    if (found.length === 0) {
      toast({ title: "Access Denied", description: "No restaurant profile found for this account.", variant: "destructive" });
      await secureLogout();
      setUser(null);
      setRestaurants([]);
      setActiveQueryId(null);
      localStorage.removeItem(SINGLE_KEY);
      setLoading(false);
      return;
    }

    setUser(currentUser);
    setRestaurants(found);

    if (found.length === 1) {
      const id = found[0].queryId;
      setActiveQueryId(id);
      localStorage.setItem(SINGLE_KEY, id);
      sessionStorage.removeItem(MULTI_KEY);
      console.log("[Auth] Auto-selected (single restaurant):", id);
    } else {
      localStorage.removeItem(SINGLE_KEY);
      const session = sessionStorage.getItem(MULTI_KEY);
      const valid = session ? found.find((r) => r.queryId === session) : null;
      if (valid) {
        setActiveQueryId(valid.queryId);
        console.log("[Auth] Restored restaurant from session:", valid.queryId);
      } else {
        setActiveQueryId(null);
        console.log("[Auth] Multiple restaurants — showing picker");
      }
    }
    setLoading(false);
  }, [toast]);

  useEffect(() => {
    // Bootstrap from existing session first to avoid flicker on reload
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        handleUserSession(session.user);
      } else {
        setLoading(false);
      }
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange(async (_event, session) => {
      if (session?.user) {
        handleUserSession(session.user);
      } else {
        setUser(null);
        setRestaurants([]);
        setActiveQueryId(null);
        localStorage.removeItem(SINGLE_KEY);
        sessionStorage.removeItem(MULTI_KEY);
        setLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, [handleUserSession]);

  const setActiveRestaurant = useCallback((queryId: string) => {
    setRestaurants((prev) => {
      const found = prev.find((r) => r.queryId === queryId);
      if (!found) {
        console.warn("[Auth] setActiveRestaurant: unknown queryId:", queryId);
        return prev;
      }
      setActiveQueryId(queryId);
      if (prev.length === 1) localStorage.setItem(SINGLE_KEY, queryId);
      else sessionStorage.setItem(MULTI_KEY, queryId);
      console.log("[Auth] Active restaurant switched to:", queryId);
      return prev;
    });
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  }, []);

  const logout = useCallback(async () => {
    await secureLogout();
  }, []);

  const activeRestaurant = restaurants.find((r) => r.queryId === activeQueryId) ?? null;

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        restaurants,
        activeRestaurantId: activeQueryId,
        restaurantId: activeQueryId,
        restaurantData: activeRestaurant?.data ?? null,
        needsRestaurantSelection: !loading && user !== null && restaurants.length > 1 && activeQueryId === null,
        setActiveRestaurant,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}
